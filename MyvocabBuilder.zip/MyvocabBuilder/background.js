// background.js - 稳定修复版

// background.js - 翻译逻辑优化版

const POS_MAP = {
    "noun": "n.", "verb": "v.", "adjective": "adj.", "adverb": "adv.",
    "pronoun": "pron.", "preposition": "prep.", "conjunction": "conj.",
    "interjection": "int.", "article": "art.", "abbreviation": "abbr."
};

// ... 这里的监听代码保持不变 ...
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "lookupWord") {
        handleLookup(request.word).then(sendResponse);
        return true; 
    } else if (request.action === "incrementCount") {
        incrementWordCount(request.word);
    } else if (request.action === "openDashboard") {
        chrome.runtime.openOptionsPage();
    }
});

async function handleLookup(word) {
    word = word.toLowerCase().trim();
    const data = await chrome.storage.local.get("vocabList");
    let vocabList = data.vocabList || {};

    if (vocabList[word]) {
        vocabList[word].count += 1;
        await chrome.storage.local.set({ vocabList });
        return { status: "updated", data: vocabList[word] };
    }

    try {
        const [phoneticRes, transRes] = await Promise.allSettled([
            fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${word}`).then(r => r.json()),
            fetch(`https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=zh-CN&dt=t&dt=bd&q=${encodeURIComponent(word)}`).then(r => r.json())
        ]);

        // 1. 音标解析
        let phonetic = "/?/";
        if (phoneticRes.status === "fulfilled" && Array.isArray(phoneticRes.value)) {
            const p = phoneticRes.value[0];
            phonetic = p.phonetic || (p.phonetics && p.phonetics[0] ? p.phonetics[0].text : "/?/");
        }

        // 2. 中文解析 (核心修改部分)
        let definition_cn = "";
        const result = transRes.status === "fulfilled" ? transRes.value : null;

        if (result) {
            // A. 获取核心翻译 (Best Translation) - 比如 "语言"
            let mainMeanings = [];
            if (result[0] && Array.isArray(result[0])) {
                result[0].forEach(item => {
                    // item[0] 是翻译词, item[1] 是原词，我们只取翻译词
                    if (item[0]) mainMeanings.push(item[0]);
                });
            }
            // 只要第一个最准的，比如 "Language" -> "语言"
            // 去重并取前1个，避免重复
            const mainTrans = [...new Set(mainMeanings)][0]; 

            // B. 获取详细字典 (Rich Data) - 比如 "n. 语, 文..."
            let details = "";
            if (result[1] && Array.isArray(result[1])) {
                result[1].forEach(item => {
                    const posName = item[0];
                    const cnWords = item[1];
                    if (posName && Array.isArray(cnWords)) {
                        const posAbbr = POS_MAP[posName] || posName + ".";
                        // 过滤掉和核心翻译完全一样的词，避免废话
                        const filteredWords = cnWords.filter(w => w !== mainTrans).slice(0, 3);
                        
                        if (filteredWords.length > 0) {
                            details += `<span class='pos-tag'>${posAbbr}</span> ${filteredWords.join("，")}<br>`;
                        }
                    }
                });
            }

            // C. 组合显示
            // 如果有核心翻译，把它加粗显示在第一行
            if (mainTrans) {
                definition_cn += `<span class="main-trans">${mainTrans}</span>`;
            }
            // 如果有详细分类，接在后面
            if (details) {
                definition_cn += details;
            }
        }
        
        if (!definition_cn) definition_cn = "暂无释义";

        const newWordData = {
            word: word,
            phonetic: phonetic,
            definition_cn: definition_cn, 
            count: 1,
            timestamp: Date.now()
        };

        vocabList[word] = newWordData;
        await chrome.storage.local.set({ vocabList });
        return { status: "success", data: newWordData };

    } catch (error) {
        console.error("查词失败:", error);
        return { status: "error", message: "网络错误" };
    }
}

// ... 辅助函数不变 ...
async function incrementWordCount(word) {
    const data = await chrome.storage.local.get("vocabList");
    let vocabList = data.vocabList || {};
    if (vocabList[word]) {
        vocabList[word].count += 1;
        await chrome.storage.local.set({ vocabList });
    }
}