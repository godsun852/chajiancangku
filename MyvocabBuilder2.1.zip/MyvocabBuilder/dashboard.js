// dashboard.js - 最终完整版

let allWords = []; // 存储所有单词数据

document.addEventListener('DOMContentLoaded', () => {
    loadData();
    
    // 绑定顶部筛选事件
    document.getElementById('search-input').addEventListener('input', renderTable);
    document.getElementById('sort-select').addEventListener('change', renderTable);
    
    // 绑定底部按钮事件
    document.getElementById('clear-btn').addEventListener('click', clearAll);
    document.getElementById('export-btn').addEventListener('click', exportData);

    // --- 核心：使用事件委托处理删除 ---
    document.getElementById('vocab-tbody').addEventListener('click', (e) => {
        if (e.target && e.target.classList.contains('action-btn')) {
            const wordToDelete = e.target.dataset.word;
            deleteWord(wordToDelete);
        }
    });
});

function loadData() {
    chrome.storage.local.get("vocabList", (data) => {
        const vocabList = data.vocabList || {};
        allWords = Object.values(vocabList);
        
        // 更新总数显示
        document.getElementById('total-count').textContent = allWords.length;
        
        renderTable();
    });
}

function renderTable() {
    const tbody = document.getElementById('vocab-tbody');
    const searchTerm = document.getElementById('search-input').value.toLowerCase();
    const sortType = document.getElementById('sort-select').value;

    // 1. 过滤
    let filtered = allWords.filter(item => item.word.toLowerCase().includes(searchTerm));

    // 2. 排序
    filtered.sort((a, b) => {
        if (sortType === 'count-desc') return b.count - a.count;
        if (sortType === 'time-desc') return (b.timestamp || 0) - (a.timestamp || 0);
        if (sortType === 'alpha-asc') return a.word.localeCompare(b.word);
    });

    // 3. 渲染
    tbody.innerHTML = '';
    filtered.forEach((item, index) => {
        const tr = document.createElement('tr');
        
        // 生成纯文本的释义，用于 title 提示 (鼠标悬停显示)
        // 将 <br> 替换为换行符，并移除 span 标签
        const plainTextDef = item.definition_cn
            ? item.definition_cn.replace(/<br>/g, '\n').replace(/<[^>]+>/g, '')
            : "暂无释义";

        tr.innerHTML = `
            <td>${index + 1}</td>
            <td class="word-text">${item.word}</td>
            <td class="phonetic-text">${item.phonetic}</td>
            
            <td class="cn-text" title="${plainTextDef}">
                ${item.definition_cn}
            </td>
            
            <td><span class="count-badge">${item.count}</span></td>
            <td>
                <button class="action-btn" data-word="${item.word}">删除</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

// 删除功能
function deleteWord(word) {
    if(!confirm(`确定要删除 "${word}" 吗？`)) return;
    
    chrome.storage.local.get("vocabList", (data) => {
        let vocabList = data.vocabList || {};
        
        // 如果数据存在，则删除
        if (vocabList[word]) {
            delete vocabList[word];
            
            chrome.storage.local.set({ vocabList }, () => {
                // 1. 重新加载后台表格
                loadData(); 

                // 2. 【关键】通知所有打开的标签页刷新高亮 (撕掉黄色标签)
                chrome.tabs.query({}, function(tabs) {
                    tabs.forEach(tab => {
                        // 排除掉没有权限的页面(chrome://...)
                        if (tab.url && !tab.url.startsWith('chrome://')) {
                            chrome.tabs.sendMessage(tab.id, {action: "refreshHighlight"}).catch(() => {
                                // 忽略连接错误的标签页 (比如未加载完的页面)
                            });
                        }
                    });
                });
            });
        }
    });
}

// 清空所有功能
function clearAll() {
    if(!confirm("⚠️ 警告：确定要清空所有生词本数据吗？此操作无法撤销！")) return;
    
    chrome.storage.local.set({ vocabList: {} }, () => {
        loadData();
        // 通知网页清除高亮
        chrome.tabs.query({}, function(tabs) {
            tabs.forEach(tab => {
                if (tab.url && !tab.url.startsWith('chrome://')) {
                    chrome.tabs.sendMessage(tab.id, {action: "refreshHighlight"}).catch(() => {});
                }
            });
        });
    });
}

// 导出功能
function exportData() {
    const dataStr = JSON.stringify(allWords, null, 2);
    const blob = new Blob([dataStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `生词本备份_${new Date().toLocaleDateString()}.json`;
    a.click();
}