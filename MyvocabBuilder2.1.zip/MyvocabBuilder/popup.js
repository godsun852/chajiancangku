// popup.js - 修复版

document.addEventListener('DOMContentLoaded', () => {
    // 1. 绑定打开后台按钮
    const openDashBtn = document.getElementById('open-dash-btn');
    if(openDashBtn) {
        openDashBtn.addEventListener('click', () => {
            chrome.runtime.openOptionsPage();
        });
    }

    // 2. 加载列表
    loadPopupList();
});

function loadPopupList() {
    chrome.storage.local.get("vocabList", (data) => {
        const vocabList = data.vocabList || {};
        const listContainer = document.getElementById('vocab-list');
        const totalCountSpan = document.getElementById('total-count');
        const emptyState = document.getElementById('empty-state');
        const table = document.getElementById('vocab-table');

        // --- 修复计数显示 ---
        const totalWords = Object.keys(vocabList).length;
        if(totalCountSpan) {
            totalCountSpan.textContent = `共 ${totalWords} 词`;
        }

        if (totalWords === 0) {
            emptyState.style.display = 'block';
            table.style.display = 'none';
            return;
        } else {
            emptyState.style.display = 'none';
            table.style.display = 'table';
        }

        // 排序：按次数降序
        let sortedWords = Object.values(vocabList).sort((a, b) => b.count - a.count);

        // 只显示前 10 个
        sortedWords = sortedWords.slice(0, 10); 

        listContainer.innerHTML = '';

        sortedWords.forEach((item, index) => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${index + 1}</td>
                <td style="font-weight:bold; color:#333;">${item.word}</td>
                <td style="text-align:center; color:#4CAF50;">${item.count}</td>
                <td style="text-align:center;">
                    <button class="mini-del-btn" data-word="${item.word}" title="删除">×</button>
                </td>
            `;
            listContainer.appendChild(tr);
        });

        // 绑定删除事件
        document.querySelectorAll('.mini-del-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const word = e.target.dataset.word;
                deleteWord(word);
            });
        });
    });
}

// popup.js 中的 deleteWord 函数应该长这样：

function deleteWord(word) {
    // ... 前面的代码 ...
    chrome.storage.local.get("vocabList", (data) => {
        let vocabList = data.vocabList || {};
        delete vocabList[word];
        
        chrome.storage.local.set({ vocabList }, () => {
            loadPopupList(); // 刷新列表
            
            // 【关键】：通知当前网页“数据变了，请刷新高亮”
            chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
                if(tabs[0]) {
                    chrome.tabs.sendMessage(tabs[0].id, {action: "refreshHighlight"});
                }
            });
        });
    });
}