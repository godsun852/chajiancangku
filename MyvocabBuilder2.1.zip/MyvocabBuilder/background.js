// background.js - 必应词典稳定版 (Bing Dictionary)

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "lookupWord") {
        handleLookup(request.word).then(sendResponse);
        return true; 
    } else if (request.action === "incrementCount") {
        incrementWordCount(request.word);
    } else if (request.action === "openDashboard") {
        chrome.runtime.openOptionsPage();
    }
});

async function handleLookup(word) {
    word = word.toLowerCase().trim();
    const data = await chrome.storage.local.get("vocabList");
    let vocabList = data.vocabList || {};

    // 1. 查缓存
    if (vocabList[word]) {
        vocabList[word].count += 1;
        await chrome.storage.local.set({ vocabList });
        return { status: "updated", data: vocabList[word] };
    }

    try {
        // 2. 爬取必应词典网页
        // 必应的服务器响应速度非常快，通常在 100-300ms 内
        const response = await fetch(`https://cn.bing.com/dict/search?q=${encodeURIComponent(word)}`);
        const text = await response.text(); // 获取网页 HTML 源码

        // --- 核心解析逻辑 ---
        
        // A. 抓取音标
        // 必应的音标通常在 <div class="hd_prUS">美 [xxxx]</div> 这样的结构里
        // 我们用正则粗略匹配一下 "美 [音标]" 或者 "英 [音标]"
        let phonetic = "/?/";
        const phoneticMatch = text.match(/美\s*\[(.*?)\]/) || text.match(/英\s*\[(.*?)\]/) || text.match(/\[(.*?)\]/);
        if (phoneticMatch && phoneticMatch[1]) {
            phonetic = `/${phoneticMatch[1]}/`;
        }

        // B. 抓取中文释义 (重点)
        // 必应的释义通常在 <meta name="description" ...> 标签里有最简洁的总结
        // 格式通常是： "必应词典为您提供hello的释义，美[həˈloʊ]...，int. 你好；喂；..."
        let definition_cn = "";
        
        // 方法1：尝试从 meta description 抓取（最快最稳）
        const metaMatch = text.match(/<meta name="description" content="(.*?)"/);
        if (metaMatch && metaMatch[1]) {
            let metaContent = metaMatch[1];
            // 去掉前面的废话 "必应词典为您提供...释义，"
            // 找到第一个 "，" 逗号或者空格后的内容，通常就是词性开始的地方
            // 我们用一个更聪明的办法：查找包含 "n." "v." "adj." 等词性的位置
            
            // 为了显示美观，我们尝试解析网页正文里的 <ul> 列表
            // 正则匹配类似：<span class="pos">n.</span><span class="def"><span>释义...</span></span>
            const posRegex = /<span class="pos">(.+?)<\/span><span class="def"><span>(.+?)<\/span><\/span>/g;
            let match;
            let found = false;
            
            while ((match = posRegex.exec(text)) !== null) {
                found = true;
                const pos = match[1]; // 词性 (如 n.)
                const def = match[2]; // 释义 (如 名字)
                definition_cn += `<br><span class='pos-tag'>${pos}</span> ${def}`;
            }
            
            // 如果正文解析失败（有时候结构会变），回退到使用 Meta 里的简单描述
            if (!found) {
                // 清理 meta 数据，只保留中文部分
                const cleanMeta = metaContent.split('，').filter(s => !s.includes('必应') && !s.includes('[')).join('，');
                definition_cn = cleanMeta || "暂无释义";
            }
        } else {
            definition_cn = "暂无释义 (未找到结果)";
        }
        
        // 去掉开头多余的 <br>
        if (definition_cn.startsWith('<br>')) {
            definition_cn = definition_cn.substring(4);
        }

        const newWordData = {
            word: word,
            phonetic: phonetic,
            definition_cn: definition_cn, 
            count: 1,
            timestamp: Date.now()
        };

        vocabList[word] = newWordData;
        await chrome.storage.local.set({ vocabList });
        return { status: "success", data: newWordData };

    } catch (error) {
        console.error("必应查词失败:", error);
        return { status: "error", message: "网络请求失败" };
    }
}

async function incrementWordCount(word) {
    const data = await chrome.storage.local.get("vocabList");
    let vocabList = data.vocabList || {};
    if (vocabList[word]) {
        vocabList[word].count += 1;
        await chrome.storage.local.set({ vocabList });
    }
}