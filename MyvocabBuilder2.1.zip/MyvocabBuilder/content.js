// content.js - 修复删除后高亮残留问题

console.log("生词本插件: 已加载");

// 1. 监听来自 popup 或 background 的刷新消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "refreshHighlight") {
        console.log("收到刷新指令，正在更新高亮...");
        init(); // 重新读取数据并刷新
    } else if (request.action === "lookupWord") {
        // 用于处理 content 自身发出的查词请求（虽然通常是发给 background，但这里保留接口）
    }
});

// 2. 快捷键监听
document.addEventListener('keydown', (e) => {
    if (e.altKey && e.code === 'KeyS') {
        e.preventDefault();
        const selection = window.getSelection().toString().trim();
        if (selection && /^[a-zA-Z\s-]+$/.test(selection)) { 
            saveWord(selection);
        } else {
            showToast("⚠️ 请先选中一个有效的英文单词", "error");
        }
    }
});

function saveWord(word) {
    showToast("🔍 正在查询...", "info");
    chrome.runtime.sendMessage({ action: "lookupWord", word: word }, (response) => {
        if (response && (response.status === "success" || response.status === "updated")) {
            showToast(`✅ 已记录: ${response.data.definition_cn}`, "success");
            init(); // 保存成功后立即刷新高亮
        } else {
            showToast("❌ 保存失败", "error");
        }
    });
}

// 3. 核心逻辑：缓存与高亮
let vocabCache = {};

function init() {
    chrome.storage.local.get("vocabList", (data) => {
        vocabCache = data.vocabList || {};
        
        // 【关键修复步骤】
        // 1. 先清理：把那些已经删除的单词的高亮去掉
        removeInvalidHighlights();
        
        // 2. 再高亮：把现有的单词高亮出来
        highlightWords();
    });
}

// 监听动态内容（防止网页滚动加载后高亮消失）
const observer = new MutationObserver(() => {
    if (window.highlightTimeout) clearTimeout(window.highlightTimeout);
    window.highlightTimeout = setTimeout(init, 1500); // 使用 init 确保包含清理逻辑
});
observer.observe(document.body, { childList: true, subtree: true });

// 执行初始化
init();

// --- 新增：清理无效高亮函数 ---
function removeInvalidHighlights() {
    // 找到所有带有我们插件标记的黄色高亮元素
    const highlights = document.querySelectorAll('.my-vocab-highlight');
    
    highlights.forEach(span => {
        const word = span.dataset.word; // 获取这个标签对应的单词
        
        // 如果这个单词已经不在我们的缓存里了（说明被删除了）
        if (!vocabCache[word]) {
            // 创建一个纯文本节点，内容就是原来的字
            const textNode = document.createTextNode(span.textContent);
            // 用纯文本替换掉黄色的 span 标签（相当于撕掉标签）
            span.parentNode.replaceChild(textNode, span);
        }
    });
    // 规范化 DOM，合并相邻的文本节点（优化网页性能）
    document.body.normalize();
}

function highlightWords() {
    const words = Object.keys(vocabCache);
    if (words.length === 0) return;
    
    words.sort((a, b) => b.length - a.length);
    const regex = new RegExp(`\\b(${words.join('|')})\\b`, 'gi');

    // 过滤掉已经在弹窗里、或者输入框里的内容
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
    const nodesToReplace = [];

    while (walker.nextNode()) {
        const node = walker.currentNode;
        const parent = node.parentNode;
        
        if (parent.closest('#vocab-popup') || 
            parent.classList.contains('my-vocab-highlight') ||
            parent.nodeName.match(/SCRIPT|STYLE|TEXTAREA|INPUT|BUTTON/) ||
            parent.isContentEditable) {
            continue;
        }
        if (node.nodeValue.match(regex)) {
            nodesToReplace.push(node);
        }
    }

    nodesToReplace.forEach(node => {
        const fragment = document.createDocumentFragment();
        let lastIndex = 0;
        node.nodeValue.replace(regex, (match, p1, offset) => {
            fragment.appendChild(document.createTextNode(node.nodeValue.slice(lastIndex, offset)));
            
            const span = document.createElement('span');
            span.className = 'my-vocab-highlight';
            span.textContent = match;
            span.dataset.word = match.toLowerCase();
            span.onclick = handleWordClick;
            fragment.appendChild(span);
            
            lastIndex = offset + match.length;
            return match;
        });
        fragment.appendChild(document.createTextNode(node.nodeValue.slice(lastIndex)));
        node.parentNode.replaceChild(fragment, node);
    });
}

function handleWordClick(e) {
    e.stopPropagation();
    const word = e.target.dataset.word;
    const data = vocabCache[word];
    
    // 如果数据不存在（比如刚删除），直接移除这个高亮并返回
    if (!data) {
        const textNode = document.createTextNode(e.target.textContent);
        e.target.parentNode.replaceChild(textNode, e.target);
        return;
    }

    chrome.runtime.sendMessage({ action: "incrementCount", word: word });

    const oldPopup = document.getElementById('vocab-popup');
    if (oldPopup) oldPopup.remove();

    const popup = document.createElement('div');
    popup.id = 'vocab-popup';
    popup.innerHTML = `
        <div class="word-title">${data.word} <span class="phonetic">[${data.phonetic}]</span></div>
        <div class="word-def-cn">${data.definition_cn}</div>
        <div class="word-count">查询次数: ${data.count + 1}</div>
    `;
    
    const rect = e.target.getBoundingClientRect();
    popup.style.top = `${rect.bottom + window.scrollY + 8}px`;
    popup.style.left = `${rect.left + window.scrollX}px`;
    document.body.appendChild(popup);

    setTimeout(() => {
        document.addEventListener('click', function close(ev) {
            if (ev.target !== popup && !popup.contains(ev.target) && ev.target !== e.target) {
                popup.remove();
                document.removeEventListener('click', close);
            }
        });
    }, 100);
}

function showToast(msg, type) {
    const div = document.createElement('div');
    div.textContent = msg;
    div.style.cssText = `
        position: fixed; top: 20px; right: 20px; padding: 12px 20px;
        border-radius: 6px; color: white; z-index: 2147483647; font-size: 14px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15); animation: fadeIn 0.3s;
        background-color: ${type === 'error' ? '#e74c3c' : (type === 'success' ? '#2ecc71' : '#34495e')};
    `;
    document.body.appendChild(div);
    setTimeout(() => div.remove(), 3000);
}